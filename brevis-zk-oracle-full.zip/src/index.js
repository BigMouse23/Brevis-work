import { Brevis } from "brevis-sdk";

async function main() {
  const brevis = new Brevis({ apiKey: process.env.BREVIS_API_KEY });
  const data = { btcPrice: "65000" };
  const proof = await brevis.prove(data);
  console.log("Generated proof hash:", proof.hash);
}

main();
