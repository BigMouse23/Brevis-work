require("dotenv").config();
const { ethers } = require("hardhat");

async function verifyData(key, proofHash) {
  const contractAddress = process.env.CONTRACT_ADDRESS;
  const BrevisOracle = await ethers.getContractFactory("BrevisOracle");
  const oracle = BrevisOracle.attach(contractAddress);
  const tx = await oracle.submitProof(key, proofHash);
  await tx.wait();
  console.log(`✅ Proof submitted for key "${key}"`);
}

verifyData("btc-price", "0x123456789abcdef123456789abcdef123456789abcdef123456789abcdef1234");
