const hre = require("hardhat");

async function main() {
  const BrevisOracle = await hre.ethers.getContractFactory("BrevisOracle");
  const oracle = await BrevisOracle.deploy();
  await oracle.deployed();
  console.log(`✅ BrevisOracle deployed at: ${oracle.address}`);
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
