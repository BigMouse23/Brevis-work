# 🧠 Brevis ZK Oracle

This project demonstrates how to integrate Brevis SDK with a smart contract to verify on-chain data using Zero-Knowledge Proofs.

## 🚀 Features
- Solidity smart contract for verified data storage  
- Proof generation using Brevis SDK  
- Node.js scripts for proof submission  
- Hardhat environment for deployment  

## 🛠 Installation
```bash
git clone https://github.com/ekalalkahfi/brevis-zk-oracle.git
cd brevis-zk-oracle
npm install
cp .env.example .env
```

## 🧩 Deploy Contract
```bash
npx hardhat run scripts/deploy.js --network sepolia
```

## 🧾 Submit Proof
```bash
node scripts/verify.js
```

## 🌐 Resources
- [Brevis Docs](https://docs.brevis.network)
- [Ethers.js](https://docs.ethers.org)
- [Hardhat](https://hardhat.org)

> “Proof is the new trust.”
